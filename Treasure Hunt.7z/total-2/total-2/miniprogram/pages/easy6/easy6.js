const app = getApp();

Page({
  data: {
    answer1: '',
    answer2: '',
    correct1: false,
    correct2: false,
    wrong1: false,
    wrong2: false,
    showResult: false,
    scanResult: '',
    showTheWorld: false,
    zt1:'',
    zt2:'',
    enter:'',
    click:'',
    QR6:''
  },

  onLoad(options) {
    this.app = getApp();
    this.setData({
      zt1: app.globalData.i18n.zt1,
      zt2: app.globalData.i18n.zt2,
      enter: app.globalData.i18n.enter,
      click:app.globalData.i18n.click,
      QR6:app.globalData.i18n.QR6,
    })

    this.setData({
      i18n: app.globalData.i18n,
    });
    if(this.data.i18n.language === "zh"){
      wx.setNavigationBarTitle({
        title: "谜题" // 使用动态语言包中的值
      });
    }
  },

  onInput1: function (event) {
    this.setData({
      answer1: event.detail.value
    });
  },

  onInput2: function (event) {
    this.setData({
      answer2: event.detail.value
    });
  },

  checkAnswer1: function () {
    const correctAnswers1 = ['Sycamore tree', 'Sycamore Tree', 'sycamore tree','WuTong Tree','Wutong Tree','wutong tree','Sycamore tree ', 'Sycamore Tree ', 'sycamore tree ','WuTong Tree ','Wutong Tree ','wutong tree ', 'Sycamore', 'Sycamore ','sycamore', 'sycamore ', 'Wutong', 'Wutong ', 'wutong', 'wutong ','悬铃木树','悬铃木','梧桐树','梧桐',]; // 可以接受的答案列表

    if (correctAnswers1.includes(this.data.answer1)) {
      this.setData({
        correct1: true,
        wrong1: false
      });
    } else {
      this.setData({
        correct1: false,
        wrong1: true
      });
    }
    this.checkOverallResult();
  },

  checkAnswer2: function () {
    const correctAnswers2 = ['4', 'four', 'Four', 'four ', 'Four ', '四']; // 可以接受的答案列表

    if (correctAnswers2.includes(this.data.answer2)) {
      this.setData({
        correct2: true,
        wrong2: false
      });
    } else {
      this.setData({
        correct2: false,
        wrong2: true
      });
    }
    this.checkOverallResult();
  },

  checkOverallResult: function () {
    if (this.data.correct1 && this.data.correct2) {
      this.setData({
        showResult: true
      });
    } else {
      this.setData({
        showResult: false
      });
    }
  },

  scanQRCode: function () {
    wx.scanCode({
      success: (res) => {
        this.setData({
          scanResult: res.result,
          //showTheWorld: res.result === 'JIFLOWS12306'
        });
        if(res.result === 'JIFLOWS12306'){
        const app = getApp();// 修改成就信息
    app.globalData.achievements[4].completed = true;
    app.globalData.achievements[4].image = app.globalData.achievements[4].image.replace('_un', '_su');
    wx.switchTab({
      url: '/pages/achievements/achievements',
    })
  }
      },
      fail: (err) => {
        wx.showToast({
          title: '扫描失败',
          icon: 'none'
        });
      }
    });
  }
});
