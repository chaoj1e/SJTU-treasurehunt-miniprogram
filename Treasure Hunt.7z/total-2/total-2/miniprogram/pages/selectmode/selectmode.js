// pages/selectmode/selectmode.js

const app = getApp();

Page({

  data: {
    achievements: [],
    hardmode: '',
    easymode: '',
    plzselectmode:'',
    slbotton:'',
    easybotton:'',
    hardbotton:'',
  },
  onLoad: function() {

    this.setData({
      hardbotton: app.globalData.i18n.hardbotton,
      easybotton: app.globalData.i18n.easybotton,
      slbotton: app.globalData.i18n.slbotton,
    });

  },

  


  // 跳转到困难模式TabBar页面
  goToHardMode: function() {
    const app = getApp();
    // 修改全局数据
    app.globalData.mode = 1;
    wx.switchTab({
      url: '/pages/map/map'
    });
  },
  // 跳转到简单模式TabBar页面
  goToEasyMode: function() {
    const app = getApp();
    // 修改全局数据
    app.globalData.mode = 2;
    wx.switchTab({
      url: '/pages/map/map'
    });
  },

  navigateToHowToPlay() {
    wx.navigateTo({
      url: '/pages/howtoplay/howtoplay' // 替换为你要跳转的页面路径
    });
  },
})