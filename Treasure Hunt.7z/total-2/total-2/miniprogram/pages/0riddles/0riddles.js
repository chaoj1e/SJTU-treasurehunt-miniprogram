Page({
  data: {
    riddle: '请点击下面的按钮查看答案',
  },

  revealRiddle() {
    this.setData({
      riddle: '谜语答案：风'
    });
  },

  navigateToNextPage() {
    wx.navigateTo({
      url: '/pages/nextpage/nextpage'
    });
  },
  
  
    showAnswer: function() {
      wx.navigateTo({
        url: '../riddle_answer/riddle_answer'
      });
    }
  
});
