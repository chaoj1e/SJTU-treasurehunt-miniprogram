Page({
  data: {
    achievements: [
      { name: '成就1', completed: false, image: '/pages/image/Huoti_2.jpg' },
      { name: '成就2', completed: false, image: '/pages/image/Huoti_2.jpg' },
      { name: '成就3', completed: false, image: '/pages/image/LBL.jpg' },
      { name: '成就4', completed: false, image: '/pages/image/LBL_2.jpg' },
      { name: '成就5', completed: false, image: '/pages/image/Youyong.jpg' }
    ]
  },
  
  onShow: function() {
    // 页面加载时检查全局变量
    const achievement1Completed = wx.getStorageSync('achievement1Completed');
    if (achievement1Completed) {
      this.data.achievements[0].completed = true;
      this.data.achievements[0].image = '/pages/image/Huoti.jpg'; // 新图片路径
      this.setData({
        achievements: this.data.achievements
      });
      // 记得在设置完毕后删除这个全局变量，避免影响后续操作
      wx.removeStorageSync('achievement1Completed');
    }
  },
});