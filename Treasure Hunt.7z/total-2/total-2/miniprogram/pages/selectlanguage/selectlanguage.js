// index.js
const app = getApp();

Page({
  data: {
  },

  onLoad() {},

  setLanguageToZh() {
    //this.updateTabBarText();
    // 更新全局变量中的语言设置为中文
    getApp().globalData.i18n = require('../../i18n/zh.js');
    wx.showToast({ title: '语言切换为中文' });
    wx.redirectTo({
      url: '/pages/teach/teach',
    })

      //this.loadAchievements();
      console.log('onLoad called'); // 调试日志
      this.getAchievements();//先获取成就
  
      // 调用云函数获取谜题数据
          wx.cloud.callFunction({
              name: 'HardRiddle3',
              success: res => {
                if (res.result.success) {
                  const riddlesData = res.result.data;
                  console.log(res.result.data);
                  // 存储到全局变量
                  app.globalData.riddlesData = riddlesData;
        console.log(riddlesData.Puzzle1Question)
                 // 检查riddle1是否存在且不为undefined
      /*  console.log(riddlesData.Puzzle1Question)
                  if (riddlesData.Puzzle1Question) {
                    this.setData({
                      riddle: riddlesData.Puzzle1Question
                    });
                  } else {
                    wx.showToast({
                      title: '获取谜题数据失败',
                      icon: 'none'
                    });
                  }*/
                } 
                  else {
                  /*wx.showToast({
                    title: res.result.message,
                    icon: 'none'
                  });*/
                }
              },
              fail: err => {
                /*console.error('调用云函数失败:', err);
                wx.showToast({
                  title: '获取数据失败，请重试',
                  icon: 'none'
                });*/
              }
            });

  },

  setLanguageToEn() {
    // 更新全局变量中的语言设置为英文
    getApp().globalData.i18n = require('../../i18n/en.js');
    wx.showToast({ title: 'Language switched to English' });
    wx.redirectTo({
      url: '/pages/teach/teach',
    })

      //this.loadAchievements();
      console.log('onLoad called'); // 调试日志
      this.getAchievements();//先获取成就
  
      // 调用云函数获取谜题数据
          wx.cloud.callFunction({
              name: 'HardRiddle',
              success: res => {
                if (res.result.success) {
                  const riddlesData = res.result.data;
                  console.log(res.result.data);
                  // 存储到全局变量
                  app.globalData.riddlesData = riddlesData;
        console.log(riddlesData.Puzzle1Question)
                 // 检查riddle1是否存在且不为undefined
      /*  console.log(riddlesData.Puzzle1Question)
                  if (riddlesData.Puzzle1Question) {
                    this.setData({
                      riddle: riddlesData.Puzzle1Question
                    });
                  } else {
                    wx.showToast({
                      title: '获取谜题数据失败',
                      icon: 'none'
                    });
                  }*/
                } 
                  else {
                  /*wx.showToast({
                    title: res.result.message,
                    icon: 'none'
                  });*/
                }
              },
              fail: err => {
                /*console.error('调用云函数失败:', err);
                wx.showToast({
                  title: '获取数据失败，请重试',
                  icon: 'none'
                });*/
              }
            });

  },

  loadAchievements: function () {
    const achievements = getApp().globalData.achievements
    this.setData({ achievements: achievements })
  },
 getAchievements: function () {
    wx.cloud.callFunction({
      name: 'SetAch',
      success: res => {
        if (res.result.success) {
          const achievements = res.result.achievements
          if (achievements.length > 0) {
            this.setData({ achievements: achievements })
            getApp().globalData.achievements = achievements
            wx.showToast({
              title: res.result.message,
              icon: 'success'
            })
          } else {
            /*wx.showToast({
              title: 'achievements 字段为空，本地数据不变',
              icon: 'none'
            })*/
          }
        } else {
          /*wx.showToast({
            title: res.result.message,
            icon: 'none'
          })*/
        }
      },
      fail: err => {
        console.error(err)
        /*wx.showToast({
          title: '云函数调用失败',
          icon: 'none'
        })*/
      }
    })
  },

});

