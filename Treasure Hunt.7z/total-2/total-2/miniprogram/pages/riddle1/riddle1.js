// pages/riddle1/riddle1.js
const app = getApp();

Page({
  data: {
    riddle: '',  // 当前谜题
    answer: '',  // 用户输入的答案
    An: '',
    showButton: false,
    enter:'',
  },

onShow:function(){
  const hardprogress = app.globalData.hardprogress;

  // 判断 hardprogress 的值，并更新页面数据
  if (hardprogress > 0) {
    this.setData({
      showButton: true
    });
  }
},

onLoad: function() {

  this.app = getApp();
    this.setData({
      enter: app.globalData.i18n.enter,
    })

    this.setData({
      i18n: app.globalData.i18n,
    });
    if(this.data.i18n.language === "zh"){
      wx.setNavigationBarTitle({
        title: "谜题" // 使用动态语言包中的值
      });
    }

  // 从全局变量中获取谜题数据
  const riddlesData = app.globalData.riddlesData;
  if (riddlesData) {
    this.setData({
      riddle: riddlesData.Puzzle1Question
    });
  }
},

  handleInputChange: function(e) {
    // 更新用户输入的答案
    this.setData({
      answer: e.detail.value
    });
  },

  checkAnswer: function() {
    const { answer } = this.data;
    const riddlesData = app.globalData.riddlesData;

    // 检查答案是否正确
    if (answer === String(riddlesData.Puzzle1Answer)) {
  // 答案正确，更新全局变量和当前页面变量，并跳转到 riddle2 页面
  app.globalData.hardprogress = 1; // 更新全局变量
  this.setData({
    hardprogress: 1
  });
      // 答案正确，跳转到 riddle2 页面
      wx.redirectTo({
        url: '/pages/riddle2/riddle2'
      });
    } else {
      // 答案错误，可以显示提示
      wx.showToast({
        title: '答案不正确，请再试试',
        icon: 'none'
      });
    }
  },


goToPreviousRiddle: function() {
  wx.switchTab({
    url: '/pages/map/map'  // 修改为你实际的上一题页面路径
  });
},

goToNextRiddle: function() {
  wx.redirectTo({
    url: '/pages/riddle2/riddle2'  // 修改为你实际的下一题页面路径
  });
}

});