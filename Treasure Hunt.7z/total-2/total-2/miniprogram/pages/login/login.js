const app = getApp();

Page({
  data: {
    showModal: false,
    userInfo: null,
    remind1:'',
    content1:'',
  },

  onLoad() {

    this.app = getApp();
    this.setData({
      remind1: app.globalData.i18n.remind1,
      content1: app.globalData.i18n.content1,
    });

    wx.cloud.init({
      env:'jiaowoxunxunbao-6gm0ar62739d13d6',
      traceUser:true,
    });
    // 调用云函数获取用户的 openid
    wx.cloud.callFunction({
      name: 'login',
      success: res => {
        const openid = res.result.openid;
        // 存储 openid 到本地缓存
        wx.setStorageSync('openid', openid);
        // 检查数据库中是否存在该 openid
        const db = wx.cloud.database();
        db.collection('users').where({
          _openid: openid
        }).get({
          success: res => {
            if (res.data.length > 0) {
              // 用户已存在，跳过登录
              this.navigateToPage();
              console.log('用户已存在，跳过登录');
            } 
          },
          fail: err => {
            console.error('数据库查询失败', err);
          }
        });
      },
      fail: err => {
        console.error('云函数调用失败', err);
      }
    });
  },

  showModal: function() {
      wx.showModal({
        title: '提示',
        content: '是否允许获取用户信息？',
        success: (res) => {
          if (res.confirm) {
            console.log('用户点击允许');
            this.getUserInfo();
          } else if (res.cancel) {
            console.log('用户点击拒绝');
          }
        }
      });
    },

    // 获取用户信息
    getUserInfo: function() {
      wx.getUserInfo({
        success: (res) => {
          this.onGetUserInfo(res);
        },
        fail: (err) => {
          console.log('获取用户信息失败：', err);
        }
      });
    },

    // 处理用户信息
    onGetUserInfo: function(e) {
      // 检查 e 是否存在以及 e.detail 是否存在
      if (e && e.userInfo) {
        console.log('用户信息：', e.userInfo);
        const userInfo = e.userInfo;
        this.setData({
          userInfo: userInfo
        });
        this.storeUserInfo(userInfo);
        this.navigateToPage();
      } else {
        console.log('获取用户信息失败：', e ? e.errMsg : 'e is undefined');
      }
    },

    // 存储用户信息
    storeUserInfo: function(userInfo) {
      const db = wx.cloud.database();
      const openid = wx.getStorageSync('openid');
      db.collection('users').add({
        data: {
          openid: openid,
          userInfo: userInfo,
          createdAt: new Date()
        },
        success: res => {
          console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id);
        },
        fail: err => {
          console.error('[数据库] [新增记录] 失败：', err);
        }
      });
    },


  navigateToPage: function() {
      wx.navigateTo({
        url: '/pages/introduction/introduction' // 这里是你要跳转到的页面的路径
      });
    }

});