const app = getApp();

Page({

  data: {
    achievements: [],
    allCompleted: false,
    language:'',
  },

  onLoad: function() {
    //console.log(app.globalData.achievements);
    //console.log('onLoad called'); // 调试日志
    this.loadAchievements();
    this.uploadachievement();
/*    console.log('onLoad called'); // 调试日志
    this.getAchievements();*/
    this.setData({language:app.globalData.i18n.language })

    //const app = getApp();
      this.setData({
        i18n: app.globalData.i18n,
      });
      if(this.data.i18n.language === "zh"){
        wx.setNavigationBarTitle({
          title: this.data.i18n.tabach // 使用动态语言包中的值
        });
      }
  },

  onShow:function(){
    this.loadAchievements();
    this.uploadachievement();
    let allCompleted = true;
    for (let i = 0; i <= 11; i++) {
      if (!this.data.achievements[i].completed) {
        allCompleted = false;
        break;
      }
    }
    this.setData({ allCompleted });

  },

  loadAchievements: function () {
    console.log('loadAchievements called'); // 调试日志
    const achievements0 = getApp().globalData.achievements
    const app = getApp();
    console.log(app.globalData.achievements[3].completed);
    this.setData({ achievements: achievements0 })
  },
 getAchievements: function () {
    wx.cloud.callFunction({
      name: 'SetAch',
      success: res => {
        if (res.result.success) {
          const achievements = res.result.achievements
          if (achievements.length > 0) {
            this.setData({ achievements: achievements })
            getApp().globalData.achievements = achievements
            /*wx.showToast({
              title: res.result.message,
              icon: 'success'
            })*/
          } else {
            /*wx.showToast({
              title: 'achievements 字段为空，本地数据不变',
              icon: 'none'
            })*/
          }
        } else {
          /*wx.showToast({
            title: res.result.message,
            icon: 'none'
          })*/
        }
      },
      fail: err => {
        console.error(err)
        /*wx.showToast({
          title: '云函数调用失败',
          icon: 'none'
        })*/
      }
    })
  },

  uploadachievement: function () {
    console.log('uploadachievement called'); // 调试日志
    const globalAchievements = getApp().globalData.achievements
    wx.cloud.callFunction({
      name: 'getData',
      data: {
        achievements: globalAchievements
      },
      success: res => {
        if (res.result.success) {
          /*wx.showToast({
            title: '上传成功',
            icon: 'success'
          })*/
        } else {
          /*wx.showToast({
            title: res.result.message,
            icon: 'none'
          })*/
        }
      },
      fail: err => {
        console.error(err)
        /*wx.showToast({
          title: '上传失败',
          icon: 'none'
        })*/
      }
    })
  },


  
});