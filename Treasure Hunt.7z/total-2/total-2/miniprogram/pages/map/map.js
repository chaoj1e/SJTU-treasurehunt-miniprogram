Page({

  /**
   * 页面的初始数据
   */
  data: {
    showIcon: true, 
    imageWidth: 4000, // 初始图片宽度
    imageHeight: 2000, // 初始图片高度
    scale: 1 ,// 初始缩放比例
    pointX: 0,  // 红点的初始 X 坐标
    pointY: 0,   // 红点的初始 Y 坐标
    pointX1: 0,
    pointY1: 0,
    pointX2: 0,
    pointY2: 0,
    pointX3: 0,
    pointY3: 0,
    pointX4: 0,
    pointY4: 0,
    pointX5: 0,
    pointY5: 0,
    pointX6: 0,
    pointY6: 0,
    pointX7: 0,
    pointY7: 0,
    pointX8: 0,
    pointY8: 0,
    pointX9: 0,
    pointY9: 0,
    pointX10: 0,
    pointY10: 0,
    pointX11: 0,
    pointY11: 0,
    hardpointX: 0,
    hardpointY: 0,
  },

  navigateToSpecificPuzzle(event) {
    const puzzlePage = event.currentTarget.dataset.page;
    wx.navigateTo({
      url: `../${puzzlePage}/${puzzlePage}` // 确保路径正确
    });
    this.app.globalData.lastPuzzlePage = puzzlePage; // 更新最后一个解谜页面
  },


  onShow(){
    const app = getApp();
      this.setData({
        mode: app.globalData.mode,
        ach: app.globalData.achievements,
        //i18n: app.globalData.i18n,
      });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    //如果语言是中文，修改tabbar
    const app = getApp();
      this.setData({
        i18n: app.globalData.i18n,
      });
      if(this.data.i18n.language === "zh"){
        wx.setNavigationBarTitle({
          title: this.data.i18n.tabmap // 使用动态语言包中的值
        });
      wx.setTabBarItem({
        index: 0,
        text: this.data.i18n.tabmap
      });
      wx.setTabBarItem({
        index: 1,
        text: this.data.i18n.tabrid
      });
      wx.setTabBarItem({
        index: 2,
        text: this.data.i18n.tabach
      });
    }

    /*  const app = getApp();
      this.setData({
        mode: app.globalData.mode
      });*/

    /*if (false) {
      this.setData({ showIcon: false });
    } else {
      this.setData({ showIcon: true });
    }*/
    // 设置红点的初始位置
    this.setData({
      pointX: 210, // 根据图片实际尺寸调整初始位置
      pointY: 240,//huoti
      pointX1: 180,
      pointY1: 610,//likelou
      pointX2: 615,
      pointY2: 1450,//siyuan lake
      pointX3: 575,
      pointY3: 1850,//siyuan gate
      pointX4: 740,
      pointY4: 1250,//bao library
      pointX5: 2050,
      pointY5: 960,//main library
      pointX6: 1650,
      pointY6: 960,//hanzi lake
      pointX7: 3950,
      pointY7: 1100,//East gate
      pointX8: 3870,
      pointY8: 1400,//LBL
      pointX9: 2100,
      pointY9: 680,//garten
      pointX10: 3110,
      pointY10: 1890,//South Gate
      pointX11: 3000,
      pointY11: 885,//rosery
      hardpointX: 3860,
      hardpointY: 1400, //困难模式龙宾楼
      imageWidth: 4000, // 初始图片宽度
      imageHeight: 2000, // 初始图片高度
      scale: 1 // 初始缩放比例
    });
  },

  onScale(event) {
    //console.log('onScale event triggered', event.detail); // 调试信息
    const scale = event.detail.scale;
    this.setData({
      scale,
      imageWidth: 4000 * scale,
      imageHeight: 2000 * scale,
      // 更新红点位置
      pointX: 150 * scale,
      pointY: 260 * scale,
      pointX1: 150 * scale,
      pointY1: 660 * scale,
      pointX2: 150 * scale,
      pointY2: 1060 * scale,
      pointX3: 450 * scale,
      pointY3: 260 * scale,
      pointX4: 450 * scale,
      pointY4: 660 * scale,
      pointX5: 450 * scale,
      pointY5: 1060 * scale,
      pointX6: 750 * scale,
      pointY6: 260 * scale,
      pointX7: 750 * scale,
      pointY7: 660 * scale,
      pointX8: 750 * scale,
      pointY8: 1060 * scale,
      pointX9: 850 * scale,
      pointY9: 1260 * scale,
      pointX10: 950 * scale,
      pointY10: 1460 * scale,
      pointX11: 2350 * scale,
      pointY11: 930 * scale,
    });
  },

  onRedPointTap1(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map1';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map1/map1'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap2(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map2';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map2/map2'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap3(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map3';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map3/map3'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap4(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map4';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map4/map4'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap5(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map5';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map5/map5'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap6(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map6';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map6/map6'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap7(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map7';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map7/map7'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap8(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map8';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map8/map8'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap9(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map9';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map9/map9'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap10(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map10';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map10/map10'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap11(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map11';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map11/map11'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap12(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    //app.globalData.lastPuzzlePage = 'map12';
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map12/map12'  // 替换为你要跳转的页面路径
    });
  },

  onRedPointTapHard(event) {
    /*wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });*/
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/map9hard/map9hard'  // 替换为你要跳转的页面路径
    });
  },

  navigateToHowToPlay() {
    wx.navigateTo({
      url: '/pages/howtoplay/howtoplay' // 替换为你要跳转的页面路径
    });
  },

  navigateToSelectMode() {
    wx.redirectTo({
      url: '/pages/selectmode/selectmode' // 替换为你要跳转的页面路径
    });
  },

  onScroll(event) {
    // 处理滚动事件的代码
    console.log(event);
  }
})