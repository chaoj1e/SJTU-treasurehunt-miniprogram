// pages/map4/map4.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showIcon: true, 
    pointX: 0,  // 红点的初始 X 坐标
    pointY: 0   // 红点的初始 Y 坐标
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if (false) {
      this.setData({ showIcon: false });
    } else {
      this.setData({ showIcon: true });
    }
    this.setData({
      pointX: 200, // 根据图片实际尺寸调整初始位置
      pointY: 800
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  onScroll: function(e) {
    // 可以在这里处理滚动事件，如果需要的话
    console.log('scroll event:', e);
  },

  onRedPointTap: function() {
    wx.showToast({
      title: '霍英东体育场！',
      icon: 'none',
      duration: 2000
    });
     // 添加跳转页面的功能
    //wx.navigateTo({
    //url: '/pages/map2/map2'  // 替换为你要跳转的页面路径
    //});
  }

})