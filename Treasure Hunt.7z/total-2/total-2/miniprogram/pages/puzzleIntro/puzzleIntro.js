Page({
  data: {},

  onLoad() {
    this.app = getApp();
  },

  navigateToPuzzle() {
      const lastPuzzlePage = this.app.globalData.lastPuzzlePage;

      if (lastPuzzlePage === 'puzzleIntro') {
        // 如果 lastPuzzlePage 是 puzzleIntro，显示弹窗提醒用户去 map 页面
        wx.showModal({
          title: '提示',
          content: '您当前已经在谜题介绍页面，请先前往地图页面。',
          showCancel: false,
          confirmText: '确定',
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定');
            }
          }
        });
        return;
      } else {
        wx.navigateTo({
          url: `../${lastPuzzlePage}/${lastPuzzlePage}` // 确保路径正确
        });
      }
    }
})