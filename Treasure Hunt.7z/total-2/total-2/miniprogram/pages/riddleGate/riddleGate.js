const app = getApp();

Page({
  data: {
    intro1:'',
    //intro2:''
    remind:'',
    content:'',
    confirm:'',
  },

  onLoad() {
    this.app = getApp();
    this.setData({
      intro1: app.globalData.i18n.RiddlesIntro1,
      //intro2: app.globalData.i18n.RiddlesIntro2,
      remind: app.globalData.i18n.remind,
      content: app.globalData.i18n.content,
      confirm: app.globalData.i18n.confirm,
      i18n: app.globalData.i18n,
    });

      if(this.data.i18n.language === "zh"){
        wx.setNavigationBarTitle({
          title: this.data.i18n.tabrid // 使用动态语言包中的值
        });
      }
  },

  navigateToPuzzle() {
      const lastPuzzlePage = this.app.globalData.lastPuzzlePage;

      if (lastPuzzlePage === 'puzzleIntro') {
        // 如果 lastPuzzlePage 是 puzzleIntro，显示弹窗提醒用户去 map 页面
        wx.showModal({
          title: `${this.data.remind}`,
          content: `${this.data.content}`,
          showCancel: false,
          confirmText: `${this.data.confirm}`,
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定');
            }
          }
        });
        return;
      } else {
        wx.navigateTo({
          url: `../${lastPuzzlePage}/${lastPuzzlePage}` // 确保路径正确
        });
      }
    }
})
