const app = getApp();
// index.js
Page({

  data: {
    hardscan:'',
  },

  onLoad(options) {
    this.app = getApp();
    this.setData({
      hardscan: app.globalData.i18n.hardscan,
    })

    this.setData({
      i18n: app.globalData.i18n,
    });
    if(this.data.i18n.language === "zh"){
      wx.setNavigationBarTitle({
        title: "扫码" // 使用动态语言包中的值
      });
    }
  },

  scanQRCode: function () {
    wx.scanCode({
      success: (res) => {
        this.setData({
          scanResult: res.result,
          //showTheWorld: res.result === 'JIFLOEWS12303'
        });
        if(res.result === 'JIFLOWS12401'){
        const app = getApp();// 修改成就信息
    app.globalData.achievements[2].completed = true;
    app.globalData.achievements[2].image = app.globalData.achievements[2].image.replace('_un', '_su');
    //this.loadAchievements();
    //this.uploadachievement();
    //console.log(app.globalData.achievements[3].completed);
    wx.switchTab({
      url: '/pages/achievements/achievements',
    })
  }
      },
      fail: (err) => {
        wx.showToast({
          title: '扫描失败',
          icon: 'none'
        });
      }
    });
  },
});