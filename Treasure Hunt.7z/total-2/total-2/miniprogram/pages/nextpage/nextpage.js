// input.js
Page({
  data: {
    inputValue: '',
    correctAnswer: '博物馆'
  },

  onInputChange(event) {
    this.setData({
      inputValue: event.detail.value
    });
  },

  checkAnswer: function() {
    if (this.data.inputValue === this.data.correctAnswer) {
      // 答案正确，更新全局变量表示成就1已完成
      wx.setStorageSync('achievement1Completed', true);
      // 导航到 achievements 页面
      wx.switchTab({
        url: '/pages/achievements/achievements'
      })
      wx.showToast({
        title: 'Correct!',
        icon: 'success'
      })
      ;
    } else {
      wx.showToast({
        title: '错误，请再试一次',
        icon: 'none'
      });
    }
  }
});