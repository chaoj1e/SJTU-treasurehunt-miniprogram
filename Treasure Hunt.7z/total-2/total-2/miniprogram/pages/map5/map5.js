const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showIcon: true, 
    pointX: 0,  // 红点的初始 X 坐标
    pointY: 0,   // 红点的初始 Y 坐标
    introbt:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    this.app = getApp();
    this.setData({
      introbt: app.globalData.i18n.introbt,
    })

    this.setData({
      i18n: app.globalData.i18n,
    });
    if(this.data.i18n.language === "zh"){
      wx.setNavigationBarTitle({
        title: "介绍" // 使用动态语言包中的值
      });
    }

    if (false) {
      this.setData({ showIcon: false });
    } else {
      this.setData({ showIcon: true });
    }
    this.setData({
      pointX: 200, // 根据图片实际尺寸调整初始位置
      pointY: 600
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  onScroll: function(e) {
    // 可以在这里处理滚动事件，如果需要的话
    console.log('scroll event:', e);
  },

  onRedPointTap: function() {
    wx.showToast({
      title: 'Treasure is here!!！',
      icon: 'none',
      duration: 2000
    });
     // 添加跳转页面的功能
    //wx.navigateTo({
    //url: '/pages/map2/map2'  // 替换为你要跳转的页面路径
    //});
  },

  onButtonTap: function() {
    /*wx.showToast({
      title: 'Button tapped!',
      icon: 'none',
      duration: 2000
    });*/
    const app = getApp();
    // 修改全局数据
    app.globalData.lastPuzzlePage = 'easy5';
    wx.navigateTo({
      url: '/pages/easy5/easy5',
    })
  }
})