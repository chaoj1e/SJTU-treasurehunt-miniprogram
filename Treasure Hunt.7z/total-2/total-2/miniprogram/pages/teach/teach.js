const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    e1:'',
    e2:'',
    e3:'',
    e4:'',
    e5:'',
    e6:'',
    e7:'',
    h1:'',
    h2:'',
    h3:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.app = getApp();
    this.setData({
      e1: app.globalData.i18n.e1,
      e2: app.globalData.i18n.e2,
      e3: app.globalData.i18n.e3,
      e4: app.globalData.i18n.e4,
      e5: app.globalData.i18n.e5,
      e6: app.globalData.i18n.e6,
      e7: app.globalData.i18n.e7,
      h1: app.globalData.i18n.h1,
      h2: app.globalData.i18n.h2,
      h3: app.globalData.i18n.h3,
      next: app.globalData.i18n.next,
    })
  },

  onJumpToSelectMode: function() {
    wx.navigateTo({
      url: '/pages/selectmode/selectmode'
    });
  },
})