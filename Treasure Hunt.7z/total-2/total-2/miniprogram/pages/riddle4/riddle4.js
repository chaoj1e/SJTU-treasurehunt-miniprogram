// pages/riddle4/riddle4.js
const app = getApp();

Page({
  data: {
    riddle: '',
    answer: '',
    showButton: false,
    enter:'',
  },

  onLoad: function() {

    this.app = getApp();
    this.setData({
      enter: app.globalData.i18n.enter,
    })

    this.setData({
      i18n: app.globalData.i18n,
    });
    if(this.data.i18n.language === "zh"){
      wx.setNavigationBarTitle({
        title: "谜题" // 使用动态语言包中的值
      });
    }
    
    const riddlesData = app.globalData.riddlesData;
    if (riddlesData) {
      this.setData({
        riddle: riddlesData.Puzzle4Question
      });
    }
  },

  onShow:function(){
    const hardprogress = app.globalData.hardprogress;
  
    // 判断 hardprogress 的值，并更新页面数据
    if (hardprogress > 3) {
      this.setData({
        showButton: true
      });
    }
  },

  handleInputChange: function(e) {
    this.setData({
      answer: e.detail.value
    });
  },

  checkAnswer: function() {
    const { answer } = this.data;
    const riddlesData = app.globalData.riddlesData;

    if (answer === String(riddlesData.Puzzle4Answer)) {
      app.globalData.hardprogress = 4; // 更新全局变量
  this.setData({
    hardprogress: 4
  });
      // 跳转到 riddle5 页面
      wx.redirectTo({
        url: '/pages/riddle5/riddle5'
      });
    } else {
      wx.showToast({
        title: '答案不正确，请再试试',
        icon: 'none'
      });
    }
  },

  goToPreviousRiddle: function() {
    wx.redirectTo({
      url: '/pages/riddle3/riddle3'  // 修改为你实际的上一题页面路径
    });
  },
  
  goToNextRiddle: function() {
    wx.redirectTo({
      url: '/pages/riddle5/riddle5'  // 修改为你实际的下一题页面路径
    });
  }

});