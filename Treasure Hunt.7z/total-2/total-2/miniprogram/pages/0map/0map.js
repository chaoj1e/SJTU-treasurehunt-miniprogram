Page({

  /**
   * 页面的初始数据
   */
  data: {
    showIcon: true, 
    imageWidth: 4000, // 初始图片宽度
    imageHeight: 2000, // 初始图片高度
    scale: 1 ,// 初始缩放比例
    pointX: 0,  // 红点的初始 X 坐标
    pointY: 0,   // 红点的初始 Y 坐标
    pointX_1: 0, // 根据图片实际尺寸调整初始位置
    pointY_1: 0,
    pointX_2: 0, // 根据图片实际尺寸调整初始位置
    pointY_2: 0,
    pointX_3: 0, // 根据图片实际尺寸调整初始位置
    pointY_3: 0,
    pointX1: 0,
    pointY1: 0,
    pointX1_1: 0,
    pointY1_1: 0,
    pointX1_2: 0,
    pointY1_2: 0,
    pointX2: 0,
    pointY2: 0,
    pointX3: 0,
    pointY3: 0,
    pointX4: 0,
    pointY4: 0,
    pointX5: 0,
    pointY5: 0,
    pointX6: 0,
    pointY6: 0,
    pointX7: 0,
    pointY7: 0,
    pointX8: 0,
    pointY8: 0,
    pointX9: 0,
    pointY9: 0,
    pointX10: 0,
    pointY10: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if (false) {
      this.setData({ showIcon: false });
    } else {
      this.setData({ showIcon: true });
    }
    // 设置红点的初始位置
    this.setData({
      pointX: 250, // 根据图片实际尺寸调整初始位置
      pointY: 360,
      pointX_1: 270, // 根据图片实际尺寸调整初始位置
      pointY_1: 320,
      pointX_2: 290, // 根据图片实际尺寸调整初始位置
      pointY_2: 360,
      pointX_3: 310, // 根据图片实际尺寸调整初始位置
      pointY_3: 340,
      pointX1: 150,
      pointY1: 660,
      pointX1_1: 360,
      pointY1_1: 660,
      pointX1_2: 150,
      pointY1_2: 700,
      pointX2: 600,
      pointY2: 1060,
      pointX3: 900,
      pointY3: 260,
      pointX4: 600,
      pointY4: 660,
      pointX5: 900,
      pointY5: 1060,
      pointX6: 900,
      pointY6: 800,
      pointX7: 2500,
      pointY7: 2500,
      pointX8: 2500,
      pointY8: 1060,
      pointX9: 2500,
      pointY9: 1260,
      pointX10: 2500,
      pointY10: 1460,
      imageWidth: 4000, // 初始图片宽度
      imageHeight: 2000, // 初始图片高度
      scale: 1 // 初始缩放比例
    });
  },

  onScale(event) {
    console.log('onScale event triggered', event.detail); // 调试信息
    const scale = event.detail.scale;
    this.setData({
      scale,
      imageWidth: 4000 * scale,
      imageHeight: 2000 * scale,
      // 更新红点位置
      pointX: 150 * scale,
      pointY: 260 * scale,
      pointX1: 150 * scale,
      pointY1: 660 * scale,
      pointX2: 150 * scale,
      pointY2: 1060 * scale,
      pointX3: 450 * scale,
      pointY3: 260 * scale,
      pointX4: 450 * scale,
      pointY4: 660 * scale,
      pointX5: 450 * scale,
      pointY5: 1060 * scale,
      pointX6: 750 * scale,
      pointY6: 260 * scale,
      pointX7: 750 * scale,
      pointY7: 660 * scale,
      pointX8: 750 * scale,
      pointY8: 1060 * scale,
      pointX9: 850 * scale,
      pointY9: 1260 * scale,
      pointX10: 950 * scale,
      pointY10: 1460 * scale
    });
  },

  onRedPointTap1(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });

    getApp().globalData.locationData = "lbl";

    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap2(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap3(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap4(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap5(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap6(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap7(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap8(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap9(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap10(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  onRedPointTap11(event) {
    wx.showToast({
      title: 'Treasure is here !!!',
      icon: 'none',
      duration: 2000
    });
    // 添加跳转页面的功能
    wx.navigateTo({
      url: '/pages/introduction/introduction'  // 替换为你要跳转的页面路径
    });
  },
  
  onScroll(event) {
    // 处理滚动事件的代码
    console.log(event);
  }
})
