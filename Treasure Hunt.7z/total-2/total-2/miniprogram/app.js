// app.js

import en from './i18n/en.js';
import zh from './i18n/zh.js';

App({
  onLaunch() {

    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'jiaowoxunxunbao-6gm0ar62739d13d6', // 你的云开发环境 ID
        traceUser: true,
      })
    }

    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })

    // 更新 tabBar 的文本
    /*const tab = this.globalData.i18n;
    wx.setTabBarItem({
      index: 0,
      text: tab.tabmap
    });
    wx.setTabBarItem({
      index: 1,
      text: tab.tabrid
    });
    wx.setTabBarItem({
      index: 2,
      text: tab.tabach
    });*/

  },


  
  globalData: {
    userInfo: null,
    locationData: null,
    riddlesData: null, // 用于存储从数据库中抽取的谜题数据
    mode: 2, //2是简单，1是困难
    lastPuzzlePage:'puzzleIntro',
    //language: 'en', // 默认语言
    i18n: en, // 默认中文
    hardprogress: 0,
    achievements: [
            { name: 'East Main Gate',name1:'东大门', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/dongdamen_un.png'},
            { name: 'Fok Ying Tung Sports     Center',name1:'霍英东体育馆', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/huoti_un.png' },
            { name: 'Longbin Building',name1:'龙宾楼', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/LBL_un.png' },
            { name: 'Siyuan Lake',name1:'思源湖', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/siyuanhu_un.png' },
            { name: 'Main Library',name1:'主图书馆', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/zhutu_un.png' },
            { name: 'Hanze Lake',name1:'涵泽湖', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/hanze_un.png' },
            { name: 'Rose Garden',name1:'蔷薇园', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/qiangweiyuan_un.png' },
            { name: 'Siyuan Gate',name1:'思源门', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/sityuanmen_un.png' },
            { name: 'South Main Gate',name1:'凯旋门', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/kaixuanmen_un.png' },
            { name: 'Botanical Garden',name1:'植物园', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/zhuwu_un.png' },
            { name: 'YueKong Pao Library',name1:'包玉刚图书馆', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/baotu_un.png' },
            { name: 'Science Laboratory       Buildings',name1:'理科实验楼', completed: false, image: 'cloud://jiaowoxunxunbao-6gm0ar62739d13d6.6a69-jiaowoxunxunbao-6gm0ar62739d13d6-1327659204/likeshiyanlou_un.png'},
    ],
  },

  updateTabBarText: function() {
    const tabBar = wx.getTabBar ? wx.getTabBar() : null;
    if (tabBar) {
      tabBar.setData({
        list: [
          {
            pagePath: "pages/map/map",
            text: "i18n.tabmap",
            iconPath: "pages/image/icon_map_selected.png",
            selectedIconPath: "pages/image/icon_map_selected.png"
          },
          {
            pagePath: "pages/riddleGate/riddleGate",
            text: i18n.tabrid,
            iconPath: "pages/image/icon_riddles_selected.png",
            selectedIconPath: "pages/image/icon_riddles_selected.png"
          },
          {
            pagePath: "pages/achievements/achievements",
            text: i18n.tabach,
            iconPath: "pages/image/icon_achievements_selected.png",
            selectedIconPath: "pages/image/icon_achievements_selected.png"
          }
        ]
      });
    }
  }

})
