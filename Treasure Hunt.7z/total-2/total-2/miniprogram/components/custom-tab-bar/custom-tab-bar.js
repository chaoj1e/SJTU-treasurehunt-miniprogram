Component({
  properties: {
    borderStyle: {
      type: String,
      value: "blue" // 默认边框颜色
    },
    color: {
      type: String,
      value: "#f9c22b" // 默认颜色
    },
    selectedColor: {
      type: String,
      value: "#3cc51f" // 默认选中颜色
    },
    list: {
      type: Array,
      value: [
        {
          pagePath: "/pages/0map/0map",
          text: "地图",
          iconPath: "/pages/image/icon_map_selected.png",
          selectedIconPath: "/pages/image/icon_map_selected.png"
        },
        {
          pagePath: "/pages/0riddles/0riddles",
          text: "谜题",
          iconPath: "/pages/image/icon_riddles_selected.png",
          selectedIconPath: "/pages/image/icon_riddles_selected.png"
        },
        {
          pagePath: "/pages/0achievements/0achievements",
          text: "成就",
          iconPath: "/pages/image/icon_achievements_selected.png",
          selectedIconPath: "/pages/image/icon_achievements_selected.png"
        }
      ]
    }
  },
  data: {
    selected: 0 // 默认选中第一个 Tab
  },
  methods: {
    switchTab(e) {
      const { path, index } = e.currentTarget.dataset;
      wx.navigateTo({ url: path }); // 使用 wx.switchTab 代替 wx.navigateTo
      this.setData({
        selected: index
      });
    }
  }
});