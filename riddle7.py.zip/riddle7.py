import csv
from itertools import product

# 定义谜题库，每个谜题绑定一个答案和难度
puzzle_library = {
    # 关卡1
    "1.1a": {"question": "This destination is a student center and named after a donator on the wall. Question: How many doors does the destination have?", "answer": "4", "difficulty": 1},
    "1.1b": {"question": "He is a donator whose first name is John and find his personal introduction on the third floor. Question: Which number appears most in the first two paragraphs of his introduction?", "answer": "9", "difficulty": 2},
    "1.2a": {"question": "It is denoted by someone and who born in the year that Ray Kerr discovered an exact solution to the Einstein field equations of general relativity that describes a rotating black hole. Question: How many doors does the destination have?", "answer": "4", "difficulty": 3},
    "1.2b": {"question": "He was once the CTO of Alibaba in USA and he is on the donation wall. Question: Which number appears most in the first two paragraphs of his introduction on the third floor?", "answer": "9", "difficulty": 4},
    "1.3a": {"question": "It's on the floor which is the smallest odd prime number. It is the biggest room on this floor. Question: How many doors does the destination have?", "answer": "4", "difficulty": 1},
    "1.3b": {"question": "It is a personal introduction of a donator. He entered SJTU in 1985 and went to UM in 1987. Question: Which number appears most in the first two paragraphs of his introduction?", "answer": "9", "difficulty": 2},
    "1.4a": {"question": "The official name of this room has 4 words and it has Mac display. Question: How many doors does the destination have?", "answer": "4", "difficulty": 3},
    "1.4b": {"question": "First, find a place with a lot of introduction of famous alumnus on the third floor. Then find someone's introduction that is just on the right of the dean of Global Institute of future technology. Question: Which number appears most in the first two paragraphs of his introduction?", "answer": "9", "difficulty": 4},

    # 关卡2
    "2.1a": {"question": "This place has a bronze figure outside. Question: How many people appeared in the photo taken in the donation center that hung in this destination?", "answer": "12", "difficulty": 1},
    "2.1b": {"question": "It's a painting painted by Baoxing Gu. Question: how many horses are on the painting?", "answer": "8", "difficulty": 2},
    "2.2a": {"question": "This place is named after a figure who was born in a prime number year. Question: How many people appeared in the photo taken in the donation center that hung in this destination?", "answer": "12", "difficulty": 3},
    "2.2b": {"question": "There is a horse painting on the second floor. Question: how many horses are on the painting?", "answer": "8", "difficulty": 4},
    "2.3a": {"question": "This place is named after a figure who died in a year with factors 2, 3, 498, 664. Question: How many people appeared in the photo taken in the donation center that hung in this destination?", "answer": "12", "difficulty": 1},
    "2.3b": {"question": "It's a painting and the answer to the following question appears in the title of the painting. Question: how many horses are on the painting?", "answer": "8", "difficulty": 2},
    "2.4a": {"question": "This place is named after a figure who died in the year that Queen Victoria passed away. Question: How many people appeared in the photo taken in the donation center that hung in this destination?", "answer": "12", "difficulty": 3},
    "2.4b": {"question": "It's a painting with numbers in its title. It's on a floor that can be a factor of the number in the following question. Question: how many horses are on the painting?", "answer": "8", "difficulty": 4},

    # 关卡3
    "3.1a": {"question": "The room number can be divided by 100 and its first number is equal to the number of its digits. Question: When was it donated?", "answer": "2018", "difficulty": 1},
    "3.1b": {"question": "It's a photo on the fourth floor. President Xi appears in it. Question: When was it taken?", "answer": "2014", "difficulty": 2},
    "3.2a": {"question": "The room number is exactly a famous film name. Question: When was it donated?", "answer": "2018", "difficulty": 3},
    "3.2b": {"question": "It's a photo on the floor with the rooftop. The most important figure in China shows in this photo. Question: When was it taken?", "answer": "2014", "difficulty": 4},
    "3.3a": {"question": "The answer to the following question is its room number. When f(x) = 24x+ 3001, calculate the definite integrals ∫[0, 5] f(x) dx. Question: When was it donated?", "answer": "2018", "difficulty": 1},
    "3.3b": {"question": "It's a photo on the floor of the number that is the square of 2. President Xi is in this photo. Question: When was it taken?", "answer": "2014", "difficulty": 2},
    "3.4a": {"question": "The answer to the following question is its room number. When f(x) = 150x+ 111 , calculate the definite integrals ∫[0, 2] f(x) dx. Question: When was it donated?", "answer": "2018", "difficulty": 3},
    "3.4b": {"question": "It's a photo on the fourth floor. The most important figure in China shows in this photo. Question: When was it taken?", "answer": "2014", "difficulty": 4},

    # 关卡4
    "4.1a": {"question": "It's a photo with an English title. Question: When did its author graduate from JI?", "answer": "2015", "difficulty": 1},
    "4.1b": {"question": "It's room number only contains two factors: 2 and 5. Question: How many Chinese characters are there in its official room name?", "answer": "7", "difficulty": 2},
    "4.2a": {"question": "It's a photo whose name has three English words. Question: When did its author graduate from JI?", "answer": "2015", "difficulty": 3},
    "4.2b": {"question": "The binary representation of its room number is 101000000. Question: How many Chinese characters are there in its official room name?", "answer": "7", "difficulty": 4},
    "4.3a": {"question": "It's a photo describing love and marriage on the second floor. Question: When did its author graduate from JI?", "answer": "2015", "difficulty": 1},
    "4.3b": {"question": "The room number is the answer to this problem: What is the Fahrenheit equivalent of 160°C? Question: How many Chinese characters are there in its official room name?", "answer": "7", "difficulty": 2},
    "4.4a": {"question": "It's a photo on the same floor as the horse photo and it describes love and marriage. Question: When did its author graduate from JI?", "answer": "2015", "difficulty": 3},
    "4.4b": {"question": "The room number is equal to a famous series of Airbus which first flew in 1987. Question: How many Chinese characters are there in its official room name?", "answer": "7", "difficulty": 4},

    # 关卡5
    "5.1": {"question": "It's a love sculpture and on the same floor where you started. Question: How many people donated this together?", "answer": "3", "difficulty": 5},
    "5.2": {"question": "This is a sculpture you first see in Longbin Biulding. Question: How many people donated this together?", "answer": "3", "difficulty": 5},
}

# 定义生成谜题组合的函数
def generate_combinations(puzzle_library, target_difficulty):
    # 定义每个关卡的谜题组合
    levels = [
        ["1.1a", "1.1b", "1.2a", "1.2b", "1.3a", "1.3b", "1.4a", "1.4b"],
        ["2.1a", "2.1b", "2.2a", "2.2b", "2.3a", "2.3b", "2.4a", "2.4b"],
        ["3.1a", "3.1b", "3.2a", "3.2b", "3.3a", "3.3b", "3.4a", "3.4b"],
        ["4.1a", "4.1b", "4.2a", "4.2b", "4.3a", "4.3b", "4.4a", "4.4b"],
        ["5.1", "5.2"]
    ]
    
    # 生成所有可能的谜题组合
    all_combinations = list(product(*levels))
    
    # 过滤出满足目标难度的组合
    valid_combinations = []
    for combo in all_combinations:
        total_difficulty = sum(puzzle_library[p]["difficulty"] for p in combo)
        if total_difficulty == target_difficulty:
            valid_combinations.append(combo)
    
    return valid_combinations

# 生成难度系数等于20的谜题组合
target_difficulty = 20
combinations = generate_combinations(puzzle_library, target_difficulty)

# 将组合信息写入CSV文件
csv_file_path = "/Users/zhumingyuandediannao/desktop/riddle_data.csv"
with open(csv_file_path, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(["Combo", "Puzzle1Question", "Puzzle1Answer", "Puzzle2Question", "Puzzle2Answer", "Puzzle3Question", "Puzzle3Answer", "Puzzle4Question", "Puzzle4Answer", "Puzzle5Question", "Puzzle5Answer"])
    for i, combo in enumerate(combinations, start=1):
        row = [f"Combo {i}"]
        for puzzle_id in combo:
            puzzle = puzzle_library[puzzle_id]
            row.extend([str(puzzle["question"]), str(puzzle["answer"])])
        writer.writerow(row)

csv_file_path
